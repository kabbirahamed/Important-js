function responsiveMenu($width){
    if ($(window).width() <  $width) {
        $("#menu").hide();
    }else {
        $("#menu").show();
    }        
    $('.menu-button').on('click' , function(){
        $("#menu").slideToggle(500);

        return false;
    })
}
responsiveMenu(767);
